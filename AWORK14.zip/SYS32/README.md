# BOOT
This is an Operating System that is fully ready. It can run old MS-DOS programs but has a advanced user interface (GUI). This is the 32 bit version that has faster and better proccessing while having its own programming language and many thing that windows today would have, even an internet browser. You can put these files on a floppy disk or a bland HardDrive to boot it up, even on modern computers as well! If you want to run it without booting it, you can use DosBox to do so. Just drag the BOOT.BAT file onto the DosBox Shortcut to boot it. If
you want to see a picture click on the file SYSPIC.PNG to see how it looks. 

*Do not copy SETUP.EXE onto the floppy, that is to install it as a Virtual System on Windows Vista - 10

# WINDOWS
Using SETUP.EXE, you can install Avix OS 486 v2.0 - Windows Edition onto your Windows Vista - 10 computer as a Virtual System. 

Requirements
=============
Windows - Vista, 7, 8, 10

CPU Speed - 1 GHz

RAM - 1 GB

# MS-DOS

If you are using MS-DOS, and you want to just put it on your hard-drive, at the DOS prompt type "install" to run the install program and let Avix 486 v2.0 install on your computer.

*You need to make sure your HIMEM.SYS file is ran and included in your CONFIG.SYS file
